"""
基站(RSU)與雲端的「邏輯規格」——這就是 SUMO 不負責、要你自己定義的部分。

- 基站「位置」由 setup_rsu.py 從路網讀出，存在 rsu_positions.json，這裡載入它
- 再補上算力、覆蓋半徑、延遲（這些都是通訊/運算邏輯，與 SUMO 無關）
- 雲端是純邏輯節點，沒有位置

數字都是「合理起始值」，之後依你的論文設定調整即可。
"""
import json
import os

# 此檔案所在資料夾（讓 load_rsus 不論從哪裡被 import 都找得到 json）
_HERE = os.path.dirname(os.path.abspath(__file__))

# ========== 通訊 / 物理參數（簡化解析模型）==========
RSU_RANGE_M      = 300        # 基站覆蓋半徑(公尺)：車離基站超過此距離就連不到
V2V_RANGE_M      = 150        # 車對車通訊半徑(公尺)
RSU_BANDWIDTH_HZ = 20e6       # 基站頻寬
V2V_BANDWIDTH_HZ = 10e6       # V2V 頻寬

# ========== 三層節點算力 (CPU 週期/秒，越大越快) ==========
# 對應你的優先級：車最弱 → 基站中等 → 雲最強
VEHICLE_CPU = 1.0e9          # 車上算力（最弱）
RSU_CPU     = 8.0e9          # 基站（中等）
CLOUD_CPU   = 50.0e9         # 雲端（最強）

# ========== 各層「額外」固定延遲 (秒) ==========
# 反映卸載優先級 車 < 基站 < 雲：越往上層傳輸延遲越高
LOCAL_EXTRA_LATENCY = 0.000   # 本地執行，無傳輸
V2V_EXTRA_LATENCY   = 0.005   # 5 ms（車對車，近）
RSU_EXTRA_LATENCY   = 0.020   # 20 ms（車→基站）
CLOUD_EXTRA_LATENCY = 0.100   # 100 ms（基站→雲，回程慢）

# ========== 能耗係數（簡化）==========
VEHICLE_ENERGY_PER_CYCLE = 1e-9   # 車輛每個 CPU 週期的耗能


def load_rsus(path=None):
    """載入基站位置，並補上算力/覆蓋等執行期屬性。"""
    if path is None:
        path = os.path.join(_HERE, "rsu_positions.json")
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    rsus = {}
    for rid, info in raw.items():
        rsus[rid] = {
            "x": info["x"], "y": info["y"],
            "cpu":   RSU_CPU,
            "range": RSU_RANGE_M,
            "load":  0.0,         # 當前負載，執行期動態更新
        }
    return rsus


# 雲端：純邏輯節點，沒有座標，視為隨時可達（透過基站回傳）
CLOUD = {
    "cpu":           CLOUD_CPU,
    "extra_latency": CLOUD_EXTRA_LATENCY,
    "load":          0.0,
}


if __name__ == "__main__":
    # 小測試：印出載入的基站（需先跑過 setup_rsu.py 產生 json）
    try:
        rsus = load_rsus()
        print(f"載入 {len(rsus)} 個基站：")
        for rid, r in rsus.items():
            print(f"  {rid}: 座標({r['x']:.1f},{r['y']:.1f}) "
                  f"算力{r['cpu']/1e9:.0f}GHz 覆蓋{r['range']}m")
        print(f"雲端：算力{CLOUD['cpu']/1e9:.0f}GHz 延遲{CLOUD['extra_latency']*1000:.0f}ms")
    except FileNotFoundError:
        print("尚未找到 rsu_positions.json，請先在有路網的電腦上執行 setup_rsu.py")
