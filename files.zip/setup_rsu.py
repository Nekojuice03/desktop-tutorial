"""
自動放置基站(RSU)。
在「你的電腦」上跑（需要有路網檔，且已安裝 sumo）。

它會：
1. 讀你的真實路網（自動偵測檔名）
2. 找出最熱鬧的幾個路口
3. 在那些路口放 RSU，輸出兩個檔：
   - rsu.add.xml        → 給 SUMO 看（地圖上會出現藍點，純標記）
   - rsu_positions.json → 給 Python 程式讀座標（之後算通訊距離用）

執行：python setup_rsu.py
（不論你從哪個資料夾執行都可以，程式會自動切到自己所在的資料夾）
"""
import os
import glob
import json
import sys
import sumolib   # 安裝 sumo 時會一起裝；若無：pip install sumolib

# ===== 關鍵：自動切換到「此腳本所在的資料夾」=====
# 解決「從別的地方執行 → 相對路徑找不到檔」的問題
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)
print(f"工作目錄：{SCRIPT_DIR}\n")

OUT_ADD    = "rsu.add.xml"
OUT_JSON   = "rsu_positions.json"
NUM_RSU    = 5      # 想放幾個基站（你的區域不大，3~5 個通常夠）
MIN_DEGREE = 4      # 只在「連接邊數 >= 此值」的真路口放（過濾小路口）


def find_net_file():
    """自動偵測路網檔：先找常見名稱，再用萬用字元找。"""
    for name in ("osm.net.xml.gz", "osm.net.xml"):
        if os.path.exists(name):
            return name
    hits = glob.glob("*.net.xml*")
    return hits[0] if hits else None


NET_FILE = find_net_file()
if NET_FILE is None:
    print("找不到路網檔（*.net.xml 或 *.net.xml.gz）。")
    print("這個資料夾裡有：")
    for fn in sorted(os.listdir(".")):
        print("   ", fn)
    print("\n請確認 setup_rsu.py 和你的路網檔放在同一個資料夾。")
    sys.exit(1)

print(f"找到路網檔：{NET_FILE}")
net = sumolib.net.readNet(NET_FILE)

# 找真正的路口：排除內部節點，並要求足夠的連接邊數
nodes = [
    n for n in net.getNodes()
    if n.getType() != "internal"
    and (len(n.getIncoming()) + len(n.getOutgoing())) >= MIN_DEGREE
]

if not nodes:
    print(f"\n找不到連接邊數 >= {MIN_DEGREE} 的路口，"
          f"試著把 MIN_DEGREE 調小（例如 3 或 2）再跑一次。")
    sys.exit(1)

# 依「連接邊數」由多到少排序，取前 NUM_RSU 個 = 最熱鬧的路口
nodes.sort(key=lambda n: len(n.getIncoming()) + len(n.getOutgoing()), reverse=True)
selected = nodes[:NUM_RSU]

rsus = {}
with open(OUT_ADD, "w", encoding="utf-8") as f:
    f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
    f.write('<additional>\n')
    for i, n in enumerate(selected):
        x, y = n.getCoord()                       # 路網座標(與 TraCI getPosition 同系統)
        rid = f"rsu_{i}"
        rsus[rid] = {"x": x, "y": y, "junction": n.getID()}
        # 藍色點，layer 拉高確保蓋在地圖上方看得到
        f.write(f'    <poi id="{rid}" x="{x:.2f}" y="{y:.2f}" '
                f'type="RSU" color="0,0,255" layer="200"/>\n')
    f.write('</additional>\n')

with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(rsus, f, ensure_ascii=False, indent=2)

print(f"\n已放置 {len(selected)} 個基站：")
for rid, info in rsus.items():
    print(f"  {rid} @ 路口 {info['junction']}  座標({info['x']:.1f}, {info['y']:.1f})")
print(f"\n輸出：{OUT_ADD}（給SUMO看）、{OUT_JSON}（給Python讀）")
